import time
print("Waiting 20 seconds for Lambda update to complete...")
time.sleep(20)
print("Done!")
