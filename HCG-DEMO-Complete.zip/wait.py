import time
print("Waiting 40 seconds for agent preparation...")
time.sleep(40)
print("Done!")
